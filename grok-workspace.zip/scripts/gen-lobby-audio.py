#!/usr/bin/env python3
"""Soft hotel-lobby ambient loop: Rhodes-like piano, warm pad, hush noise."""
from __future__ import annotations

import math
import random
import struct
import wave
from pathlib import Path

SR = 22050
BPM = 70
BEAT = 60.0 / BPM
BARS = 16
BEATS_PER_BAR = 4
DURATION = BARS * BEATS_PER_BAR * BEAT
N = int(SR * DURATION)

# ii–V–I lounge: Dm9 | G13 | Cmaj9 | Cmaj9  (repeat)
CHORDS = [
    [146.83, 174.61, 220.00, 293.66, 329.63],  # D2 F2 A2 D3 E3
    [196.00, 246.94, 293.66, 349.23, 440.00],  # G2 B2 D3 F3 A3
    [130.81, 164.81, 196.00, 261.63, 329.63],  # C2 E2 G2 C3 E3
    [130.81, 164.81, 196.00, 246.94, 329.63],  # C2 E2 G2 B2 E3
]


def clamp(x: float) -> float:
    return max(-1.0, min(1.0, x))


def env_exp(t: float, attack: float, decay: float) -> float:
    if t < 0:
        return 0.0
    if t < attack:
        return t / attack
    return math.exp(-(t - attack) / decay)


def rhodes(t: float, freq: float, vel: float) -> float:
    if t < 0:
        return 0.0
    e = env_exp(t, 0.008, 1.85) * vel
    a = math.sin(2 * math.pi * freq * t)
    b = 0.28 * math.sin(2 * math.pi * freq * 2.003 * t)
    c = 0.08 * math.sin(2 * math.pi * freq * 4.02 * t + 0.4)
    d = 0.04 * math.sin(2 * math.pi * freq * 7.1 * t)
    return e * (a + b + c + d)


def pad_sample(t: float, freq: float, phase: float) -> float:
    # slow attack, always on
    a = 1.0 - math.exp(-t * 0.35) if t < 8 else 1.0
    det = 0.004
    s = (
        math.sin(2 * math.pi * freq * t + phase)
        + 0.7 * math.sin(2 * math.pi * freq * (1 + det) * t + phase * 1.3)
        + 0.35 * math.sin(2 * math.pi * freq * 0.5 * t + phase)
    )
    return a * s * 0.045


def bass(t: float, freq: float) -> float:
    e = env_exp(t, 0.02, 0.9)
    return e * 0.22 * math.sin(2 * math.pi * freq * t) * (1.0 + 0.15 * math.sin(2 * math.pi * 6 * t))


def main() -> None:
    rng = random.Random(17)
    left = [0.0] * N
    right = [0.0] * N

    bar_len = BEATS_PER_BAR * BEAT
    # chord pads
    for bar in range(BARS):
        chord = CHORDS[bar % 4]
        t0 = bar * bar_len
        i0 = int(t0 * SR)
        i1 = min(N, int((t0 + bar_len + 0.4) * SR))
        for i in range(i0, i1):
            t = i / SR - t0
            acc = 0.0
            for k, f in enumerate(chord):
                acc += pad_sample(t, f, k * 0.7)
            # fade between bars
            fade = 1.0
            if t < 0.15:
                fade = t / 0.15
            remain = (i1 - i) / SR
            if remain < 0.2:
                fade *= remain / 0.2
            pan_l = 0.92
            pan_r = 1.08
            left[i] += acc * fade * pan_l
            right[i] += acc * fade * pan_r

    # piano voicings on beats 1 and 3, occasional color on 2.5
    voicings = [
        [293.66, 349.23, 440.00, 587.33],
        [246.94, 349.23, 392.00, 587.33],
        [261.63, 329.63, 392.00, 523.25],
        [246.94, 329.63, 392.00, 523.25],
    ]
    for bar in range(BARS):
        chord = voicings[bar % 4]
        t_bar = bar * bar_len
        hits = [0.0, 2.0]
        if bar % 2 == 1:
            hits.append(2.5)
        if bar % 4 == 2:
            hits.append(3.25)
        for beat in hits:
            t_hit = t_bar + beat * BEAT
            vel = 0.34 if beat == 0 else 0.22
            spread = rng.uniform(-0.12, 0.12)
            for n, f in enumerate(chord):
                delay = n * 0.012
                i0 = int((t_hit + delay) * SR)
                length = int(2.4 * SR)
                for k in range(length):
                    i = i0 + k
                    if i >= N:
                        break
                    t = k / SR
                    s = rhodes(t, f * (1 + 0.0008 * n), vel * (1 - n * 0.08))
                    left[i] += s * (0.9 - spread)
                    right[i] += s * (0.9 + spread)

    # soft bass roots on 1
    roots = [73.42, 98.00, 65.41, 65.41]
    for bar in range(BARS):
        t_hit = bar * bar_len
        i0 = int(t_hit * SR)
        length = int(1.6 * SR)
        f = roots[bar % 4]
        for k in range(length):
            i = i0 + k
            if i >= N:
                break
            s = bass(k / SR, f)
            left[i] += s * 0.85
            right[i] += s * 0.85

    # air / vinyl hush
    for i in range(N):
        n = (rng.random() * 2 - 1) * 0.012
        t = i / SR
        breath = 0.7 + 0.3 * math.sin(2 * math.pi * t / 11.0)
        left[i] += n * breath
        right[i] += n * 0.9 * breath

    # loop crossfade 0.6s
    fade = int(0.6 * SR)
    for i in range(fade):
        w = i / fade
        j = N - fade + i
        left[i] = left[i] * w + left[j] * (1 - w)
        right[i] = right[i] * w + right[j] * (1 - w)
    for i in range(fade):
        left[N - fade + i] = left[i]
        right[N - fade + i] = right[i]

    # master + soft limiter
    peak = 1e-9
    for i in range(N):
        peak = max(peak, abs(left[i]), abs(right[i]))
    gain = 0.38 / peak
    out = Path("/workspace/public/audio/lobby.wav")
    with wave.open(str(out), "w") as wf:
        wf.setnchannels(2)
        wf.setsampwidth(2)
        wf.setframerate(SR)
        packed = bytearray()
        for i in range(N):
            l = clamp(left[i] * gain)
            r = clamp(right[i] * gain)
            packed += struct.pack("<hh", int(l * 32767), int(r * 32767))
        wf.writeframes(packed)
    print(f"wrote {out} {DURATION:.1f}s peak={peak:.3f}")


if __name__ == "__main__":
    main()
