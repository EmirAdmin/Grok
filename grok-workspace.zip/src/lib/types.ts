export type Lang = "en" | "fa" | "ru" | "tr" | "zh" | "ko" | "ja";

export type Tab = "market" | "forum" | "hub" | "tasks" | "storage";

export type Overlay =
  | "menu"
  | "cart"
  | "item"
  | "thread"
  | "profile"
  | "orders"
  | "deposit"
  | "filters"
  | "support"
  | "terms"
  | null;

export type Category = "all" | "vehicles" | "houses" | "vip" | "skins" | "extras";

export type Rarity = "common" | "rare" | "epic" | "legendary" | "prime";

export type Loc = Record<Lang, string>;

export type ShopItem = {
  id: string;
  category: Exclude<Category, "all">;
  name: Loc;
  blurb: Loc;
  price: number;
  image: string;
  rarity: Rarity;
  meta: string;
  stickers: Array<"new" | "hot" | "prime" | "limited" | "lspd">;
  hold?: string;
  tint: string;
};

export type Thread = {
  id: string;
  title: Loc;
  body: Loc;
  author: string;
  tag: Loc;
  replies: number;
  views: number;
  pinned?: boolean;
  created: string;
};

export type Mission = {
  id: string;
  title: Loc;
  detail: Loc;
  reward: number;
  xp: number;
  progress: number;
  goal: number;
};

export type EventCard = {
  id: string;
  title: Loc;
  detail: Loc;
  when: Loc;
  image: string;
};

export type Order = {
  id: string;
  itemId: string;
  price: number;
  at: number;
};

export type CartLine = { id: string; qty: number };
